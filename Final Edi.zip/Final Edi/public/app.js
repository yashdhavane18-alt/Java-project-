// Government Scheme Finder - Frontend JavaScript

// Global Variables
const API_BASE_URL = '/api';
let currentUser = null;
let currentSchemeId = null;

const FILTER_STORAGE_KEY = 'gsf_dashboard_filters_v1';
const ONBOARDING_STORAGE_KEY = 'gsf_seen_dashboard_onboarding_v1';

// Utility Functions
function showAlert(message, type = 'danger') {
    const alertContainer = document.getElementById('alertContainer');
    const alertHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            <i class="bi bi-${type === 'success' ? 'check-circle' : type === 'info' ? 'info-circle' : 'exclamation-triangle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    alertContainer.innerHTML = alertHTML;
    
    // Auto dismiss after 5 seconds
    setTimeout(() => {
        const alert = alertContainer.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}

function getAuthToken() {
    return localStorage.getItem('authToken');
}

function getUserData() {
    const userData = localStorage.getItem('userData');
    return userData ? JSON.parse(userData) : null;
}

function saveFilterState(filters) {
    try {
        localStorage.setItem(FILTER_STORAGE_KEY, JSON.stringify(filters || {}));
    } catch (e) {
        console.warn('Failed to save filters to localStorage:', e);
    }
}

function loadFilterState() {
    try {
        const raw = localStorage.getItem(FILTER_STORAGE_KEY);
        return raw ? JSON.parse(raw) : null;
    } catch (e) {
        console.warn('Failed to load filters from localStorage:', e);
        return null;
    }
}

function makeAuthenticatedRequest(url, options = {}) {
    const token = getAuthToken();
    if (!token) {
        window.location.href = '/';
        return Promise.reject('No auth token');
    }
    
    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        ...options.headers
    };
    
    return fetch(url, { ...options, headers });
}

function showLoading(show = true) {
    const spinner = document.getElementById('loadingSpinner');
    const container = document.getElementById('schemesContainer');
    
    if (show) {
        spinner.classList.remove('d-none');
        container.innerHTML = '';
    } else {
        spinner.classList.add('d-none');
    }
}

async function explainCurrentScheme() {
    if (!currentSchemeId) return;

    const explainBtn = document.getElementById('modalExplainBtn');
    const explanationSection = document.getElementById('schemeAiExplanationSection');
    const explanationContent = document.getElementById('schemeAiExplanationContent');

    if (!explainBtn || !explanationSection || !explanationContent) return;

    try {
        explainBtn.disabled = true;
        explainBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>Generating...';
        explanationSection.style.display = 'block';
        explanationContent.textContent = 'Analyzing this scheme for you...';

        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/${currentSchemeId}/explain`, {
            method: 'POST',
            body: JSON.stringify({})
        });

        const data = await response.json();

        if (data.success && data.explanation) {
            // Remove markdown bold markers like **Heading** to avoid showing stars
            let cleaned = data.explanation.replace(/\*\*(.*?)\*\*/g, '$1');
            explanationContent.innerHTML = cleaned.replace(/\n/g, '<br>');
        } else {
            explanationContent.textContent = data.message || 'Could not generate explanation. Please try again.';
        }
    } catch (error) {
        console.error('Explain scheme error:', error);
        explanationContent.textContent = 'Error while generating explanation. Please try again later.';
    } finally {
        explainBtn.disabled = false;
        explainBtn.innerHTML = '<i class="bi bi-robot me-1"></i>AI explain this for me';
    }
}

// Authentication Functions
function checkAuth() {
    const token = getAuthToken();
    const userData = getUserData();
    
    if (!token || !userData) {
        window.location.href = '/';
        return false;
    }
    
    currentUser = userData;
    updateUserDisplay();
    return true;
}

function updateUserDisplay() {
    if (currentUser) {
        document.getElementById('userNameDisplay').textContent = currentUser.full_name;
        document.getElementById('welcomeUserName').textContent = currentUser.full_name;
        const adminLink = document.getElementById('adminLink');
        if (adminLink) {
            if (currentUser.isAdmin) {
                adminLink.classList.remove('d-none');
            } else {
                adminLink.classList.add('d-none');
            }
        }
    }
}

function logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    window.location.href = '/';
}

// Profile Functions
function loadUserProfile() {
    if (!currentUser) return;
    
    document.getElementById('filterAge').value = currentUser.age || '';
    document.getElementById('filterGender').value = currentUser.gender || '';
    document.getElementById('filterCaste').value = currentUser.caste || '';
    document.getElementById('filterIncome').value = currentUser.income || '';
    document.getElementById('filterProfession').value = currentUser.profession || '';
    
    showAlert('Profile loaded into filters. Click "Find Matching Schemes" to see results.', 'info');
}

function clearFilters() {
    document.getElementById('filterAge').value = '';
    document.getElementById('filterGender').value = '';
    document.getElementById('filterCaste').value = '';
    document.getElementById('filterIncome').value = '';
    document.getElementById('filterProfession').value = '';
    document.getElementById('searchKeyword').value = '';
    
    // Clear results
    document.getElementById('schemesContainer').innerHTML = `
        <div class="empty-state-container">
            <i class="bi bi-search empty-state-icon"></i>
            <h5 class="text-muted mt-3">Use filters or search to find schemes</h5>
            <p class="text-muted mb-3">Click "Use My Profile" to get personalized recommendations</p>
            <button class="btn btn-success" onclick="loadUserProfile(); findSchemes();">
                <i class="bi bi-person-check me-1"></i>Use My Profile to Get Started
            </button>
        </div>
    `;
    document.getElementById('resultsTitle').textContent = 'Available Schemes';

    try {
        localStorage.removeItem(FILTER_STORAGE_KEY);
    } catch (e) {
        console.warn('Failed to clear saved filters:', e);
    }
}

// Scheme Functions
async function findSchemes() {
    const filters = {
        age: document.getElementById('filterAge').value,
        gender: document.getElementById('filterGender').value,
        caste: document.getElementById('filterCaste').value,
        income: document.getElementById('filterIncome').value,
        profession: document.getElementById('filterProfession').value,
        keyword: document.getElementById('searchKeyword').value
    };
    
    // Remove empty filters
    Object.keys(filters).forEach(key => {
        if (!filters[key]) delete filters[key];
    });
    
    try {
        // Persist filter state for future visits
        saveFilterState(filters);
    } catch (e) {
        console.warn('Failed to save filter state:', e);
    }

    showLoading(true);
    
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/filter`, {
            method: 'POST',
            body: JSON.stringify(filters)
        });
        
        const data = await response.json();
        
        if (data.success) {
            displaySchemes(data.schemes, data.message);
            loadRecommendations();
        } else {
            showAlert(data.message || 'Failed to load schemes');
        }
    } catch (error) {
        console.error('Find schemes error:', error);
        showAlert('Network error. Please try again.');
    } finally {
        showLoading(false);
    }
}

async function searchSchemes() {
    const keyword = document.getElementById('searchKeyword').value.trim();
    
    if (!keyword) {
        showAlert('Please enter a search keyword', 'info');
        return;
    }
    
    const filters = {
        age: document.getElementById('filterAge').value,
        gender: document.getElementById('filterGender').value,
        caste: document.getElementById('filterCaste').value,
        income: document.getElementById('filterIncome').value,
        profession: document.getElementById('filterProfession').value,
        keyword
    };

    try {
        saveFilterState(filters);
    } catch (e) {
        console.warn('Failed to save filter state from search:', e);
    }

    showLoading(true);
    
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/filter`, {
            method: 'POST',
            body: JSON.stringify(filters)
        });
        
        const data = await response.json();
        
        if (data.success) {
            displaySchemes(data.schemes, data.message);
            document.getElementById('resultsTitle').textContent = `Search Results for "${keyword}"`;
        } else {
            showAlert(data.message || 'No schemes found');
        }
    } catch (error) {
        console.error('Search schemes error:', error);
        showAlert('Network error. Please try again.');
    } finally {
        showLoading(false);
    }
}

function displaySchemes(schemes, message = '') {
    const container = document.getElementById('schemesContainer');
    
    if (schemes.length === 0) {
        container.innerHTML = `
            <div class="empty-state-container">
                <i class="bi bi-exclamation-circle empty-state-icon"></i>
                <h5 class="text-muted mt-3">No schemes found</h5>
                <p class="text-muted mb-3">Try adjusting your filters or search terms</p>
                <button class="btn btn-outline-primary" onclick="clearFilters()">
                    <i class="bi bi-arrow-clockwise me-1"></i>Clear Filters
                </button>
            </div>
        `;
        return;
    }
    
    let html = '';
    if (message) {
        html += `<div class="alert alert-info"><i class="bi bi-info-circle me-2"></i>${message}</div>`;
    }
    
    const grid = schemes.map(scheme => createSchemeCard(scheme)).join('');
    html += `<div class="schemes-grid">${grid}</div>`;
    
    container.innerHTML = html;
}

function createSchemeCard(scheme) {
    return `
        <div class="card scheme-card mb-3 fade-in">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="flex-grow-1">
                        <h5 class="card-title mb-1">${scheme.scheme_name}</h5>
                        <p class="card-text text-secondary mb-2">${scheme.summary}</p>
                    </div>
                    <button class="btn btn-outline-primary btn-sm btn-bookmark ms-2" 
                            onclick="toggleBookmark(${scheme.id}, this)">
                        <i class="bi bi-bookmark${scheme.isBookmarked ? '-fill' : ''} me-1"></i>
                        ${scheme.isBookmarked ? 'Saved' : 'Save'}
                    </button>
                </div>
                <div class="mt-3">
                    <span class="badge bg-light text-dark me-1 mb-1">
                        <i class="bi bi-calendar me-1"></i>Age: ${scheme.min_age || 0}-${scheme.max_age || 100}
                    </span>
                    <span class="badge bg-light text-dark me-1 mb-1">
                        <i class="bi bi-briefcase me-1"></i>Profession: ${scheme.target_profession || 'Any'}
                    </span>
                    <span class="badge bg-light text-dark me-1 mb-1">
                        <i class="bi bi-currency-rupee me-1"></i>Income: ${scheme.max_income || 'Any'}
                    </span>
                </div>
                <button class="btn btn-primary mt-3" onclick="showSchemeDetails(${scheme.id})">
                    <i class="bi bi-eye me-1"></i>View Details
                </button>
            </div>
        </div>
    `;
}

async function showSchemeDetails(schemeId) {
    currentSchemeId = schemeId;
    
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/${schemeId}`);
        const data = await response.json();
        
        if (data.success) {
            const scheme = data.scheme;
            
            document.getElementById('schemeModalTitle').textContent = scheme.scheme_name;
            
            const modalBody = document.getElementById('schemeModalBody');
            modalBody.innerHTML = `
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-info-circle me-2 text-primary"></i>Description</h6>
                    <p>${scheme.description}</p>
                </div>
                
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-gift me-2 text-success"></i>Key Benefits</h6>
                    <div>${formatListContent(scheme.benefits, 'benefits')}</div>
                </div>
                
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-check-circle me-2 text-info"></i>Eligibility Criteria</h6>
                    <div>${formatListContent(scheme.eligibility, 'eligibility')}</div>
                </div>
                
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-file-text me-2 text-warning"></i>Documents Required</h6>
                    <div>${formatListContent(scheme.documents_required, 'documents')}</div>
                </div>
                
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-list-ol me-2 text-primary"></i>How to Apply</h6>
                    <ol class="ps-3">
                        ${formatApplicationSteps(scheme.application_process)}
                    </ol>
                </div>
                
                ${scheme.official_link ? `
                <div class="scheme-detail-section">
                    <h6><i class="bi bi-link-45deg me-2 text-primary"></i>Official Website</h6>
                    <a href="${scheme.official_link}" target="_blank" class="btn btn-outline-primary">
                        <i class="bi bi-box-arrow-up-right me-1"></i>Visit Official Site
                    </a>
                </div>
                ` : ''}

                <div class="scheme-detail-section" id="schemeAiExplanationSection" style="display:none;">
                    <h6><i class="bi bi-robot me-2 text-success"></i>AI Explanation</h6>
                    <div id="schemeAiExplanationContent" class="text-muted small"></div>
                </div>
            `;
            
            // Update bookmark button
            const bookmarkBtn = document.getElementById('modalBookmarkBtn');
            updateBookmarkButton(bookmarkBtn, scheme.isBookmarked);
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('schemeModal'));
            modal.show();
            
        } else {
            showAlert(data.message || 'Failed to load scheme details');
        }
    } catch (error) {
        console.error('Scheme details error:', error);
        showAlert('Network error. Please try again.');
    }
}

function formatListContent(content, type = 'default') {
    if (!content) return '';
    
    // Clean up any encoding issues and normalize bullet points
    let cleanContent = content
        .replace(/\?/g, '') // Remove question marks
        .replace(/[•·▪▫‣⁃]/g, '•') // Normalize different bullet characters
        .replace(/^\s*[\-\*\+]\s*/gm, '• '); // Convert dashes to bullets
    
    // Convert bullet points to HTML list with icons
    const lines = cleanContent.split('\n').filter(line => line.trim());
    if (lines.some(line => line.includes('•') || line.startsWith('-'))) {
        const listItems = lines.map(line => {
            const cleanLine = line.replace(/^[•\-\*\+]\s*/, '').trim();
            if (!cleanLine) return '';
            
            let icon = 'bi-check-circle-fill text-success';
            if (type === 'eligibility') icon = 'bi-person-check-fill text-info';
            if (type === 'documents') icon = 'bi-file-earmark-text-fill text-warning';
            
            return `<li><i class="bi ${icon} me-2"></i>${cleanLine}</li>`;
        }).filter(item => item);
        
        return `<ul class="list-unstyled ${type}-list">${listItems.join('')}</ul>`;
    }
    
    return `<p>${cleanContent}</p>`;
}

function formatApplicationSteps(content) {
    if (!content) return '';
    
    // Clean up any encoding issues
    let cleanContent = content.replace(/\?/g, ''); // Remove question marks
    
    const lines = cleanContent.split('\n').filter(line => line.trim());
    const steps = lines.map(line => {
        const cleanLine = line.replace(/^[•\-\d\.]\s*/, '').trim();
        return cleanLine ? `<li class="mb-2">${cleanLine}</li>` : '';
    }).filter(item => item);
    
    return steps.join('');
}

async function toggleBookmark(schemeId, buttonElement) {
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/bookmark/${schemeId}`, {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            const isBookmarked = data.action === 'added';
            updateBookmarkButton(buttonElement, isBookmarked);
            showAlert(data.message, 'success');
        } else {
            showAlert(data.message || 'Failed to update bookmark');
        }
    } catch (error) {
        console.error('Bookmark error:', error);
        showAlert('Network error. Please try again.');
    }
}

function toggleBookmarkFromModal() {
    if (currentSchemeId) {
        const bookmarkBtn = document.getElementById('modalBookmarkBtn');
        toggleBookmark(currentSchemeId, bookmarkBtn);
    }
}

function updateBookmarkButton(button, isBookmarked) {
    const icon = button.querySelector('i');
    
    if (isBookmarked) {
        button.classList.add('bookmarked');
        icon.className = 'bi bi-bookmark-fill me-1';
        button.innerHTML = '<i class="bi bi-bookmark-fill me-1"></i>Bookmarked';
    } else {
        button.classList.remove('bookmarked');
        icon.className = 'bi bi-bookmark me-1';
        button.innerHTML = '<i class="bi bi-bookmark me-1"></i>Bookmark';
    }
}

async function showBookmarks() {
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/user/bookmarks`);
        const data = await response.json();
        
        if (data.success) {
            displaySchemes(data.schemes.map(scheme => ({ ...scheme, isBookmarked: true })), 
                          `Your Bookmarked Schemes (${data.schemes.length})`);
            document.getElementById('resultsTitle').textContent = 'My Bookmarks';
        } else {
            showAlert(data.message || 'Failed to load bookmarks');
        }
    } catch (error) {
        console.error('Bookmarks error:', error);
        showAlert('Network error. Please try again.');
    }
}

async function loadRecommendations() {
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/user/recommendations`);
        const data = await response.json();
        
        if (data.success && data.schemes.length > 0) {
            const container = document.getElementById('recommendationsContainer');
            let html = '';
            
            data.schemes.slice(0, 3).forEach(scheme => {
                html += createSchemeCard(scheme);
            });
            
            container.innerHTML = html;
            document.getElementById('recommendationsSection').classList.remove('d-none');
        }
    } catch (error) {
        console.error('Recommendations error:', error);
    }
}

function showProfile() {
    window.location.href = '/profile.html';
}

// Chatbot Functions
function toggleChatbot() {
    const chatbotWindow = document.getElementById('chatbotWindow');
    const chatbotLabel = document.getElementById('chatbotLabel');
    const isVisible = chatbotWindow.style.display === 'flex';
    
    // Hide the label when chatbot is clicked
    if (chatbotLabel) {
        chatbotLabel.style.display = 'none';
    }
    
    if (isVisible) {
        chatbotWindow.style.display = 'none';
    } else {
        chatbotWindow.style.display = 'flex';
        chatbotWindow.classList.add('slide-up');
    }
}

async function sendMessage() {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Add user message to chat
    addMessageToChat(message, 'user');
    input.value = '';
    
    // Add typing indicator
    const typingId = addTypingIndicator();
    
    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/chat`, {
            method: 'POST',
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        
        // Remove typing indicator
        removeTypingIndicator(typingId);
        
        if (data.success) {
            addMessageToChat(data.response, 'bot');
        } else {
            addMessageToChat('Sorry, I encountered an error. Please try again.', 'bot');
        }
    } catch (error) {
        console.error('Chat error:', error);
        removeTypingIndicator(typingId);
        addMessageToChat('Sorry, I encountered an error. Please try again.', 'bot');
    }
}

function addMessageToChat(message, sender) {
    const messagesContainer = document.getElementById('chatbotMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;
    
    if (sender === 'bot') {
        messageDiv.innerHTML = `<i class="bi bi-robot me-2"></i>${message}`;
    } else {
        messageDiv.textContent = message;
    }
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function addTypingIndicator() {
    const messagesContainer = document.getElementById('chatbotMessages');
    const typingDiv = document.createElement('div');
    const typingId = 'typing-' + Date.now();
    
    typingDiv.id = typingId;
    typingDiv.className = 'message bot';
    typingDiv.innerHTML = '<i class="bi bi-robot me-2"></i><span class="loading-spinner me-2"></span>Typing...';
    
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    return typingId;
}

function removeTypingIndicator(typingId) {
    const typingElement = document.getElementById(typingId);
    if (typingElement) {
        typingElement.remove();
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    if (!checkAuth()) return;
    
    // Add enter key support for search
    document.getElementById('searchKeyword').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchSchemes();
        }
    });

    // Add enter key support for natural language search
    const nlSearchInput = document.getElementById('nlSearchInput');
    if (nlSearchInput) {
        nlSearchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                naturalLanguageSearch();
            }
        });
    }
    
    // Add enter key support for chat
    document.getElementById('chatInput').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
    
    // Restore saved filters if any
    const savedFilters = loadFilterState();
    if (savedFilters) {
        if (savedFilters.age) document.getElementById('filterAge').value = savedFilters.age;
        if (savedFilters.gender) document.getElementById('filterGender').value = savedFilters.gender;
        if (savedFilters.caste) document.getElementById('filterCaste').value = savedFilters.caste;
        if (savedFilters.income) document.getElementById('filterIncome').value = savedFilters.income;
        if (savedFilters.profession) document.getElementById('filterProfession').value = savedFilters.profession;
        if (savedFilters.keyword) document.getElementById('searchKeyword').value = savedFilters.keyword;

        // Auto-run search with saved filters to restore previous state
        findSchemes();
    } else {
        // Show a light onboarding hint only on first dashboard visit
        try {
            const seen = localStorage.getItem(ONBOARDING_STORAGE_KEY);
            if (!seen) {
                showAlert('Tip: Use "Use My Profile" then "Find Matching Schemes" or try Smart Search to get personalized schemes.', 'info');
                localStorage.setItem(ONBOARDING_STORAGE_KEY, '1');
            }
        } catch (e) {
            console.warn('Failed to persist onboarding flag:', e);
        }

        // Load initial recommendations when there is no saved filter state
        loadRecommendations();
    }
});

async function naturalLanguageSearch() {
    const input = document.getElementById('nlSearchInput');
    if (!input) return;

    const message = input.value.trim();
    if (!message) {
        showAlert('Please describe your situation or what you are looking for.', 'info');
        return;
    }

    showLoading(true);

    try {
        const response = await makeAuthenticatedRequest(`${API_BASE_URL}/schemes/nl-search`, {
            method: 'POST',
            body: JSON.stringify({ message })
        });

        const data = await response.json();

        if (data.success) {
            displaySchemes(data.schemes, data.message);
            document.getElementById('resultsTitle').textContent = 'Smart Search Results';
        } else {
            showAlert(data.message || 'No schemes found for your query.');
        }
    } catch (error) {
        console.error('Natural language search error:', error);
        showAlert('Network error during smart search. Please try again.', 'danger');
    } finally {
        showLoading(false);
    }
}

// Handle browser back/forward buttons
window.addEventListener('popstate', function(e) {
    // Handle navigation if needed
});
