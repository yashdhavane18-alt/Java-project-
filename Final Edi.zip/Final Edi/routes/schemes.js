const express = require('express');
const { executeQuery } = require('../db');
const { verifyToken } = require('./auth');
const router = express.Router();

// Helper function to convert income to numeric value for comparison
const getIncomeValue = (income) => {
    const incomeMap = {
        '<1 Lakh': 1,
        '1-3 Lakh': 2,
        '3-5 Lakh': 3,
        '>5 Lakh': 4
    };
    return incomeMap[income] || 0;
};

// Simple Levenshtein distance for fuzzy matching on scheme names
const levenshteinDistance = (a, b) => {
    if (!a || !b) return Number.MAX_SAFE_INTEGER;
    a = a.toLowerCase();
    b = b.toLowerCase();
    const m = a.length;
    const n = b.length;

    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;

    for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
            const cost = a[i - 1] === b[j - 1] ? 0 : 1;
            dp[i][j] = Math.min(
                dp[i - 1][j] + 1,      // deletion
                dp[i][j - 1] + 1,      // insertion
                dp[i - 1][j - 1] + cost // substitution
            );
        }
    }

    return dp[m][n];
};

// Multi-Criteria Filtering Algorithm
router.post('/filter', verifyToken, async (req, res) => {
    try {
        const { age, gender, caste, income, profession, keyword } = req.body;
        
        const filters = [];
        const params = [];
        
        // Age filter
        if (age) {
            filters.push(` AND ? >= min_age AND ? <= max_age`);
            params.push(age, age);
        }
        
        // Gender filter
        if (gender) {
            filters.push(` AND (target_gender = 'Any' OR target_gender = ?)`);
            params.push(gender);
        }
        
        // Caste filter
        if (caste) {
            filters.push(` AND (target_caste = 'Any' OR target_caste = ?)`);
            params.push(caste);
        }
        
        // Income filter
        if (income) {
            const userIncomeValue = getIncomeValue(income);
            filters.push(` AND (max_income = 'Any' OR 
                      (max_income = '<1 Lakh' AND ? <= 1) OR
                      (max_income = '1-3 Lakh' AND ? <= 2) OR
                      (max_income = '3-5 Lakh' AND ? <= 3) OR
                      (max_income = '>5 Lakh' AND ? <= 4))`);
            params.push(userIncomeValue, userIncomeValue, userIncomeValue, userIncomeValue);
        }
        
        // Profession filter
        if (profession) {
            filters.push(` AND (target_profession = 'Any' OR target_profession = ?)`);
            params.push(profession);
        }

        const trimmedKeyword = keyword?.trim();

        if (trimmedKeyword) {
            const lowerKeyword = trimmedKeyword.toLowerCase();

            // Extra semantic restriction: if user asks about insurance,
            // only return schemes explicitly mentioning insurance
            let extraCondition = '';
            const extraParams = [];
            if (lowerKeyword.includes('insurance')) {
                extraCondition = ` AND (scheme_name LIKE ? OR summary LIKE ? OR description LIKE ?)`;
                extraParams.push('%insurance%', '%insurance%', '%insurance%');
            }

            // If the keyword looks like a full scheme name (long phrase), try a strict name match first
            let schemes = [];
            if (trimmedKeyword.length >= 15 && trimmedKeyword.includes(' ')) {
                try {
                    const exactNameMatches = await executeQuery(
                        `SELECT * FROM schemes WHERE LOWER(scheme_name) LIKE ? ORDER BY scheme_name ASC LIMIT 10`,
                        [`%${trimmedKeyword.toLowerCase()}%`]
                    );

                    if (exactNameMatches && exactNameMatches.length > 0) {
                        schemes = exactNameMatches;

                        // Log search for analytics
                        try {
                            await executeQuery(
                                'INSERT INTO search_logs (user_id, keyword, filters, results_count) VALUES (?, ?, ?, ?)',
                                [
                                    req.user?.userId || null,
                                    trimmedKeyword,
                                    JSON.stringify({ age, gender, caste, income, profession }),
                                    schemes.length
                                ]
                            );
                        } catch (logError) {
                            console.error('Search log insert error (exact match):', logError);
                        }

                        return res.json({
                            success: true,
                            schemes,
                            message: `Found ${schemes.length} scheme(s) matching name exactly`,
                            searchType: 'exact_name'
                        });
                    }
                } catch (exactErr) {
                    console.error('Exact name search error:', exactErr);
                }
            }

            const query = `
                SELECT *,
                    (MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)) + 
                    (CASE WHEN scheme_name LIKE ? THEN 5 ELSE 0 END) as relevance
                FROM schemes
                WHERE MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)
                ${filters.join('')}
                ${extraCondition}
                ORDER BY relevance DESC, scheme_name ASC
                LIMIT 20;
            `;
            const queryParams = [trimmedKeyword, `%${trimmedKeyword}%`, trimmedKeyword, ...params, ...extraParams];
            schemes = await executeQuery(query, queryParams);

            // Log search for analytics
            try {
                await executeQuery(
                    'INSERT INTO search_logs (user_id, keyword, filters, results_count) VALUES (?, ?, ?, ?)',
                    [
                        req.user?.userId || null,
                        trimmedKeyword,
                        JSON.stringify({ age, gender, caste, income, profession }),
                        schemes.length
                    ]
                );
            } catch (logError) {
                console.error('Search log insert error:', logError);
            }

            // If full-text search returned nothing, try a lightweight fuzzy match on scheme_name
            if (!schemes || schemes.length === 0) {
                try {
                    const allSchemes = await executeQuery('SELECT * FROM schemes', []);
                    const keywordNorm = trimmedKeyword.toLowerCase().trim();

                    const keywordTokens = keywordNorm
                        .split(/\s+/)
                        .filter(t => t.length > 0);

                    const scored = allSchemes.map(s => {
                        const nameNorm = (s.scheme_name || '').toLowerCase();
                        const nameTokens = nameNorm
                            .split(/\s+/)
                            .filter(t => t.length > 0);

                        // Compute best token-to-token distance
                        let bestTokenDistance = Number.MAX_SAFE_INTEGER;
                        for (const kt of keywordTokens) {
                            for (const nt of nameTokens) {
                                const d = levenshteinDistance(kt, nt);
                                if (d < bestTokenDistance) bestTokenDistance = d;
                            }
                        }

                        // Also consider whole-string distance as a secondary signal
                        const wholeDistance = levenshteinDistance(keywordNorm, nameNorm);
                        const combined = Math.min(bestTokenDistance, wholeDistance);

                        return { scheme: s, distance: combined };
                    });

                    scored.sort((a, b) => a.distance - b.distance);

                    // Take only reasonably close matches (distance threshold) and max 5
                    const MAX_DISTANCE = 3; // token-level typos like 'kissan' vs 'kisan'
                    schemes = scored
                        .filter(item => item.distance <= MAX_DISTANCE)
                        .slice(0, 5)
                        .map(item => item.scheme);
                } catch (fuzzyError) {
                    console.error('Fuzzy search fallback error:', fuzzyError);
                }
            }

            return res.json({
                success: true,
                schemes,
                message: `Found ${schemes.length} relevant schemes`,
                searchType: schemes && schemes.length > 0 ? 'fulltext_or_fuzzy' : 'fulltext'
            });
        } else {
            // No keyword, just filter
            const baseQuery = `SELECT * FROM schemes WHERE 1=1 ${filters.join('')} ORDER BY scheme_name ASC`;
            const schemes = await executeQuery(baseQuery, params);

            // Log search without keyword for analytics
            try {
                await executeQuery(
                    'INSERT INTO search_logs (user_id, keyword, filters, results_count) VALUES (?, ?, ?, ?)',
                    [
                        req.user?.userId || null,
                        null,
                        JSON.stringify({ age, gender, caste, income, profession }),
                        schemes.length
                    ]
                );
            } catch (logError) {
                console.error('Search log insert error:', logError);
            }

            res.json({ success: true, schemes, message: `Found ${schemes.length} matching schemes`, searchType: 'filter' });
        }
        
    } catch (error) {
        console.error('Scheme filtering error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Get scheme details by ID
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const schemeId = req.params.id;
        
        const schemes = await executeQuery(
            'SELECT * FROM schemes WHERE id = ?',
            [schemeId]
        );
        
        if (schemes.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'Scheme not found' 
            });
        }
        
        // Check if user has bookmarked this scheme
        const bookmarks = await executeQuery(
            'SELECT bookmark_id FROM bookmarks WHERE user_id = ? AND scheme_id = ?',
            [req.user.userId, schemeId]
        );
        
        const scheme = schemes[0];
        scheme.isBookmarked = bookmarks.length > 0;

        // Log scheme view for analytics
        try {
            await executeQuery(
                'INSERT INTO scheme_views (user_id, scheme_id, source) VALUES (?, ?, ?)',
                [req.user?.userId || null, schemeId, 'direct']
            );
        } catch (logError) {
            console.error('Scheme view log insert error:', logError);
        }
        
        res.json({
            success: true,
            scheme: scheme
        });
        
    } catch (error) {
        console.error('Scheme details error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Add/Remove bookmark
router.post('/bookmark/:id', verifyToken, async (req, res) => {
    try {
        const schemeId = req.params.id;
        const userId = req.user.userId;
        
        // Check if bookmark already exists
        const existingBookmark = await executeQuery(
            'SELECT bookmark_id FROM bookmarks WHERE user_id = ? AND scheme_id = ?',
            [userId, schemeId]
        );
        
        if (existingBookmark.length > 0) {
            // Remove bookmark
            await executeQuery(
                'DELETE FROM bookmarks WHERE user_id = ? AND scheme_id = ?',
                [userId, schemeId]
            );
            
            res.json({
                success: true,
                message: 'Bookmark removed',
                action: 'removed'
            });
        } else {
            // Add bookmark
            await executeQuery(
                'INSERT INTO bookmarks (user_id, scheme_id) VALUES (?, ?)',
                [userId, schemeId]
            );
            
            res.json({
                success: true,
                message: 'Bookmark added',
                action: 'added'
            });
        }
        
    } catch (error) {
        console.error('Bookmark error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Get user bookmarks
router.get('/user/bookmarks', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const bookmarkedSchemes = await executeQuery(`
            SELECT s.id, s.scheme_name, s.summary, s.description, s.benefits, 
                   s.eligibility, s.documents_required, s.application_process, 
                   s.official_link, b.created_at as bookmarked_at
            FROM schemes s
            INNER JOIN bookmarks b ON s.id = b.scheme_id
            WHERE b.user_id = ?
            ORDER BY b.created_at DESC
        `, [userId]);
        
        res.json({
            success: true,
            schemes: bookmarkedSchemes,
            message: `Found ${bookmarkedSchemes.length} bookmarked schemes`
        });
        
    } catch (error) {
        console.error('Bookmarks fetch error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Simple Recommendation Algorithm
router.get('/user/recommendations', verifyToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        // Get current user's profile
        const userProfile = await executeQuery(
            'SELECT profession, income FROM users WHERE id = ?',
            [userId]
        );
        
        if (userProfile.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'User profile not found' 
            });
        }
        
        const { profession, income } = userProfile[0];
        
        // Find similar users (same profession and income bracket)
        const similarUsers = await executeQuery(`
            SELECT DISTINCT u.id 
            FROM users u 
            WHERE u.profession = ? AND u.income = ? AND u.id != ?
            LIMIT 50
        `, [profession, income, userId]);
        
        if (similarUsers.length === 0) {
            // Fallback: show popular schemes (by views/bookmarks) for new users or
            // when there are no similar users yet.
            const popularSchemes = await executeQuery(`
                SELECT 
                    s.id, s.scheme_name, s.summary, s.description,
                    s.benefits, s.eligibility, s.documents_required,
                    s.application_process, s.official_link,
                    COALESCE(sv.view_count, 0) AS view_count,
                    COALESCE(bc.bookmark_count, 0) AS bookmark_count
                FROM schemes s
                LEFT JOIN (
                    SELECT scheme_id, COUNT(*) AS view_count
                    FROM scheme_views
                    GROUP BY scheme_id
                ) sv ON s.id = sv.scheme_id
                LEFT JOIN (
                    SELECT scheme_id, COUNT(*) AS bookmark_count
                    FROM bookmarks
                    GROUP BY scheme_id
                ) bc ON s.id = bc.scheme_id
                ORDER BY bookmark_count DESC, view_count DESC, s.scheme_name ASC
                LIMIT 10
            `);

            return res.json({
                success: true,
                schemes: popularSchemes,
                message: 'Showing popular schemes while we learn more about users like you'
            });
        }
        
        const similarUserIds = similarUsers.map(user => user.id);
        const placeholders = similarUserIds.map(() => '?').join(',');
        
        // Get schemes bookmarked by similar users (excluding current user's bookmarks)
        const recommendedSchemes = await executeQuery(`
            SELECT DISTINCT 
                s.id, s.scheme_name, s.summary, s.description, 
                s.benefits, s.eligibility, s.documents_required, 
                s.application_process, s.official_link,
                COUNT(b.scheme_id) as bookmark_count,
                COALESCE(sv.view_count, 0) as view_count
            FROM schemes s
            INNER JOIN bookmarks b ON s.id = b.scheme_id
            LEFT JOIN (
                SELECT scheme_id, COUNT(*) as view_count
                FROM scheme_views
                GROUP BY scheme_id
            ) sv ON s.id = sv.scheme_id
            WHERE b.user_id IN (${placeholders})
            AND s.id NOT IN (
                SELECT scheme_id FROM bookmarks WHERE user_id = ?
            )
            GROUP BY s.id
            ORDER BY bookmark_count DESC, view_count DESC, s.scheme_name ASC
            LIMIT 10
        `, [...similarUserIds, userId]);

        let finalSchemes = recommendedSchemes;

        // If similar users exist but did not produce any unique schemes (rare but possible),
        // fall back to the same popular-schemes strategy.
        if (!finalSchemes || finalSchemes.length === 0) {
            finalSchemes = await executeQuery(`
                SELECT 
                    s.id, s.scheme_name, s.summary, s.description,
                    s.benefits, s.eligibility, s.documents_required,
                    s.application_process, s.official_link,
                    COALESCE(sv.view_count, 0) AS view_count,
                    COALESCE(bc.bookmark_count, 0) AS bookmark_count
                FROM schemes s
                LEFT JOIN (
                    SELECT scheme_id, COUNT(*) AS view_count
                    FROM scheme_views
                    GROUP BY scheme_id
                ) sv ON s.id = sv.scheme_id
                LEFT JOIN (
                    SELECT scheme_id, COUNT(*) AS bookmark_count
                    FROM bookmarks
                    GROUP BY scheme_id
                ) bc ON s.id = bc.scheme_id
                ORDER BY bookmark_count DESC, view_count DESC, s.scheme_name ASC
                LIMIT 10
            `);
        }

        res.json({
            success: true,
            schemes: finalSchemes,
            message: `Found ${finalSchemes.length} recommended schemes`
        });
        
    } catch (error) {
        console.error('Recommendations error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// AI-assisted scheme explanation
router.post('/:id/explain', verifyToken, async (req, res) => {
    try {
        const schemeId = req.params.id;

        const schemes = await executeQuery(
            'SELECT * FROM schemes WHERE id = ?',
            [schemeId]
        );

        if (schemes.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Scheme not found'
            });
        }

        const scheme = schemes[0];

        const userContext = {
            userId: req.user.userId,
            age: req.user.age,
            gender: req.user.gender,
            caste: req.user.caste,
            income: req.user.income,
            profession: req.user.profession
        };

        // Fallback explanation if Gemini is not configured
        if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'your-actual-gemini-api-key-here') {
            const basicExplanation = `This scheme, ${scheme.scheme_name}, provides benefits such as: ${scheme.benefits.split('\n')[0] || scheme.summary}.\n\nPlease check the eligibility section and documents required to see if it matches your profile.`;
            return res.json({
                success: true,
                explanation: basicExplanation,
                model: null
            });
        }

        try {
            const { GoogleGenerativeAI } = require('@google/generative-ai');
            const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

            const modelsToTry = [
                'gemini-2.0-flash',
                'gemini-1.5-flash-latest',
                'gemini-1.5-pro-latest',
                'gemini-pro'
            ];

            const systemPrompt = `You are a helpful assistant explaining Indian government schemes to users in *very* clear, pointwise format.

IMPORTANT:
- Do NOT just repeat or copy the scheme's description, benefits, eligibility, or application process text.
- Instead, interpret it and give **new, practical insight**: who it is really good for, when it is useful, what to watch out for, and how to make the most of it.

Your answer MUST follow this structure with short sentences:

1) **Eligibility (Yes/No + reason)**
   - Say clearly if the user is *likely eligible* or *may not be eligible*.
   - Give 1–2 short bullet points why, based on the scheme rules and the user's profile.

2) **Main benefits for you (3–5 bullets)**
   - Focus on what is most useful for *this user*, not a generic list.
   - You may reference the scheme benefits, but rephrase them in your own words.

3) **What to keep in mind / documents (3–5 bullets)**
   - Mix 1–2 key cautions or conditions (lock-in, age limits, penalties, etc.) with the most important documents.

4) **Easy steps to apply (numbered 1,2,3,...)**
   - Simple, high-level steps that help the user take action.

Rules:
- Use only numbered sections and bullet points as above.
- Keep total length under 180 words.
- No long paragraphs, no stories, no emojis.
- Start directly with section 1 (no introduction sentence).`;

            const prompt = `${systemPrompt}

User profile (may be partial):
- Age: ${userContext.age || 'Unknown'}
- Gender: ${userContext.gender || 'Unknown'}
- Caste: ${userContext.caste || 'Unknown'}
- Income: ${userContext.income || 'Unknown'}
- Profession: ${userContext.profession || 'Unknown'}

Scheme details:
- Name: ${scheme.scheme_name}
- Summary: ${scheme.summary}
- Benefits: ${scheme.benefits}
- Eligibility: ${scheme.eligibility}
- Documents required: ${scheme.documents_required}
- Application process: ${scheme.application_process}`;

            let explanation = null;
            let modelUsed = null;

            for (const modelName of modelsToTry) {
                try {
                    const model = genAI.getGenerativeModel({ model: modelName });
                    const result = await model.generateContent(prompt);
                    const response = await result.response;
                    explanation = response.text();
                    modelUsed = modelName;
                    break;
                } catch (modelError) {
                    console.log(`Explain model ${modelName} failed:`, modelError.message.split('\n')[0]);
                    if (modelError.message.includes('429') || modelError.message.includes('quota')) {
                        console.log(`Quota exceeded for ${modelName}, trying next model...`);
                    }
                    continue;
                }
            }

            if (!explanation) {
                const fallback = `This scheme, ${scheme.scheme_name}, offers benefits like: ${scheme.benefits.split('\n')[0] || scheme.summary}. Please read the eligibility and documents sections carefully to see if it matches your situation.`;
                return res.json({
                    success: true,
                    explanation: fallback,
                    model: null
                });
            }

            return res.json({
                success: true,
                explanation,
                model: modelUsed
            });

        } catch (geminiError) {
            console.error('Gemini explain API error:', geminiError.message);
            const fallback = `This scheme, ${scheme.scheme_name}, offers benefits like: ${scheme.benefits.split('\n')[0] || scheme.summary}. Please read the eligibility and documents sections carefully to see if it matches your situation.`;
            return res.json({
                success: true,
                explanation: fallback,
                model: null
            });
        }

    } catch (error) {
        console.error('Scheme explain error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Natural language search using Gemini
router.post('/nl-search', verifyToken, async (req, res) => {
    try {
        const { message } = req.body;

        if (!message || !message.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Search message is required'
            });
        }

        // If Gemini is not configured, fall back to simple keyword search using existing filter endpoint behavior
        if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'your-actual-gemini-api-key-here') {
            // Use the full message as a keyword search
            req.body.age = undefined;
            req.body.gender = undefined;
            req.body.caste = undefined;
            req.body.income = undefined;
            req.body.profession = undefined;
            req.body.keyword = message;

            // Reuse filtering logic by calling the handler functionally is complex here,
            // so we manually replicate the expected behavior with keyword only.
            const trimmedKeyword = message.trim();
            const query = `
                SELECT *,
                    (MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)) + 
                    (CASE WHEN scheme_name LIKE ? THEN 5 ELSE 0 END) as relevance
                FROM schemes
                WHERE MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)
                ORDER BY relevance DESC, scheme_name ASC
                LIMIT 20;
            `;
            const schemes = await executeQuery(query, [trimmedKeyword, `%${trimmedKeyword}%`, trimmedKeyword]);

            return res.json({
                success: true,
                schemes,
                appliedFilters: { keyword: trimmedKeyword },
                message: `Found ${schemes.length} schemes for your query`
            });
        }

        const { GoogleGenerativeAI } = require('@google/generative-ai');
        const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

        const modelsToTry = [
            // Prefer stable 2.0 Flash, then fall back to 1.5 variants
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-1.5-pro'
        ];

        const systemPrompt = `You are an assistant that converts a user's natural language description into structured filters for government schemes.

Given the user's message, extract a JSON object with these fields when possible:
- age: integer or null
- gender: one of ['Male','Female','Other'] or null
- caste: one of ['General','OBC','SC','ST'] or null
- income: one of ['<1 Lakh','1-3 Lakh','3-5 Lakh','>5 Lakh'] or null
- profession: one of ['Student','Farmer','Housewife','Employed','Unemployed','Senior Citizen'] or null
- keyword: a short keyword or phrase capturing the main topic or scheme type

Return ONLY valid JSON, no explanation text.`;

        const prompt = `${systemPrompt}\n\nUser message: "${message}"`;

        let parsedFilters = null;
        let modelUsed = null;

        for (const modelName of modelsToTry) {
            try {
                const model = genAI.getGenerativeModel({ model: modelName });
                const result = await model.generateContent(prompt);
                const response = await result.response;
                let text = response.text().trim();

                // Some Gemini responses may wrap JSON in ```json ... ``` fences.
                if (text.startsWith('```')) {
                    text = text
                        .replace(/^```json\s*/i, '')
                        .replace(/^```\s*/i, '')
                        .replace(/```$/,'')
                        .trim();
                }

                try {
                    parsedFilters = JSON.parse(text);
                    modelUsed = modelName;
                    break;
                } catch (jsonError) {
                    console.log(`Failed to parse JSON from model ${modelName}:`, jsonError.message);
                    continue;
                }
            } catch (modelError) {
                console.log(`NL search model ${modelName} failed:`, modelError.message.split('\n')[0]);
                if (modelError.message.includes('429') || modelError.message.includes('quota')) {
                    console.log(`Quota exceeded for ${modelName}, trying next model...`);
                }
                continue;
            }
        }

        if (!parsedFilters) {
            // Fallback: treat entire message as keyword
            const trimmedKeyword = message.trim();
            const query = `
                SELECT *,
                    (MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)) + 
                    (CASE WHEN scheme_name LIKE ? THEN 5 ELSE 0 END) as relevance
                FROM schemes
                WHERE MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)
                ORDER BY relevance DESC, scheme_name ASC
                LIMIT 20;
            `;
            const schemes = await executeQuery(query, [trimmedKeyword, `%${trimmedKeyword}%`, trimmedKeyword]);

            // Even in fallback mode, try to infer age from the raw text and drop clearly mismatched schemes
            let filteredSchemes = schemes;
            try {
                const lowerMsg = message.toLowerCase();
                let ageMatch = lowerMsg.match(/(\d{1,2})\s*(years?\s*old|yrs?\s*old|yrs?|yr|y\/?o|years)/);
                if (!ageMatch) {
                    ageMatch = lowerMsg.match(/\bi\s*am\s*(\d{1,2})\b/);
                }
                if (!ageMatch) {
                    ageMatch = lowerMsg.match(/\b(\d{1,2})\s*year\b/);
                }
                if (ageMatch) {
                    const ageVal = parseInt(ageMatch[1], 10);
                    if (!isNaN(ageVal) && ageVal > 0 && ageVal < 120) {
                        filteredSchemes = schemes.filter(s => {
                            const minAge = typeof s.min_age === 'number' ? s.min_age : parseInt(s.min_age, 10);
                            const maxAge = typeof s.max_age === 'number' ? s.max_age : parseInt(s.max_age, 10);

                            if (isNaN(minAge) && isNaN(maxAge)) return true;
                            if (!isNaN(minAge) && ageVal < minAge) return false;
                            if (!isNaN(maxAge) && ageVal > maxAge) return false;
                            return true;
                        });
                    }
                }
            } catch (fbFilterErr) {
                console.log('NL search fallback post-filter warning:', fbFilterErr.message);
            }

            return res.json({
                success: true,
                schemes: filteredSchemes,
                appliedFilters: { keyword: trimmedKeyword },
                model: null,
                message: `Found ${filteredSchemes.length} schemes for your query`
            });
        }

        // Enhance parsed filters using simple keyword-based rules on the raw message
        try {
            const lowerMsg = message.toLowerCase();

            // Age inference (e.g. "19 years old", "I'm 19", "I am 19 year old")
            if (!parsedFilters.age) {
                let ageMatch = lowerMsg.match(/(\d{1,2})\s*(years?\s*old|yrs?\s*old|yrs?|yr|y\/?o|years)/);
                if (!ageMatch) {
                    ageMatch = lowerMsg.match(/\bi\s*am\s*(\d{1,2})\b/);
                }
                if (!ageMatch) {
                    ageMatch = lowerMsg.match(/\b(\d{1,2})\s*year\b/);
                }
                if (ageMatch) {
                    const ageVal = parseInt(ageMatch[1], 10);
                    if (!isNaN(ageVal) && ageVal > 0 && ageVal < 120) {
                        parsedFilters.age = ageVal;
                    }
                }
            }

            // Profession inference (we allow strong hints in text to override weak model guesses)
            let detectedProfession = null;
            if (lowerMsg.includes('farmer')) detectedProfession = 'Farmer';
            else if (lowerMsg.includes('student') || lowerMsg.includes('college') || lowerMsg.includes('school')) detectedProfession = 'Student';
            else if (lowerMsg.includes('housewife') || lowerMsg.includes('homemaker')) detectedProfession = 'Housewife';
            else if (lowerMsg.includes('unemployed') || lowerMsg.includes('no job')) detectedProfession = 'Unemployed';
            else if (lowerMsg.includes('senior citizen') || lowerMsg.includes('old age') || lowerMsg.includes('retired') || lowerMsg.includes('pension')) detectedProfession = 'Senior Citizen';
            else if (lowerMsg.includes('job') || lowerMsg.includes('salaried') || lowerMsg.includes('employee') || lowerMsg.includes('working')) detectedProfession = 'Employed';

            if (detectedProfession) {
                parsedFilters.profession = detectedProfession;
            }

            // Caste / category inference
            if (!parsedFilters.caste) {
                if (lowerMsg.includes('ews')) {
                    // Map EWS to General so that user is not excluded from schemes
                    parsedFilters.caste = 'General';
                } else if (lowerMsg.includes('obc')) {
                    parsedFilters.caste = 'OBC';
                } else if (lowerMsg.includes('sc ')) {
                    parsedFilters.caste = 'SC';
                } else if (lowerMsg.includes('st ')) {
                    parsedFilters.caste = 'ST';
                }
            }

            // Income inference
            if (!parsedFilters.income) {
                if (/(below|under|less than)\s*1\s*lakh/.test(lowerMsg)) {
                    parsedFilters.income = '<1 Lakh';
                } else if (/(below|under|less than)\s*3\s*lakh/.test(lowerMsg) || /1\s*-\s*3\s*lakh/.test(lowerMsg) || /1\s*to\s*3\s*lakh/.test(lowerMsg) || /2\.5\s*lakh/.test(lowerMsg)) {
                    parsedFilters.income = '1-3 Lakh';
                } else if (/3\s*-\s*5\s*lakh/.test(lowerMsg) || /3\s*to\s*5\s*lakh/.test(lowerMsg)) {
                    parsedFilters.income = '3-5 Lakh';
                } else if (/(above|over|more than|greater than)\s*5\s*lakh/.test(lowerMsg) || />\s*5\s*lakh/.test(lowerMsg)) {
                    parsedFilters.income = '>5 Lakh';
                }
            }
        } catch (inferenceError) {
            console.log('NL search inference warning:', inferenceError.message);
        }

        // Now apply the parsed filters using the same logic as /filter
        const { age, gender, caste, income, profession, keyword } = parsedFilters;

        const filters = [];
        const params = [];

        if (age) {
            filters.push(` AND ? >= min_age AND ? <= max_age`);
            params.push(age, age);
        }

        if (gender) {
            filters.push(` AND (target_gender = 'Any' OR target_gender = ?)`);
            params.push(gender);
        }

        if (caste) {
            filters.push(` AND (target_caste = 'Any' OR target_caste = ?)`);
            params.push(caste);
        }

        if (income) {
            const userIncomeValue = getIncomeValue(income);
            filters.push(` AND (max_income = 'Any' OR 
                      (max_income = '<1 Lakh' AND ? <= 1) OR
                      (max_income = '1-3 Lakh' AND ? <= 2) OR
                      (max_income = '3-5 Lakh' AND ? <= 3) OR
                      (max_income = '>5 Lakh' AND ? <= 4))`);
            params.push(userIncomeValue, userIncomeValue, userIncomeValue, userIncomeValue);
        }

        if (profession) {
            filters.push(` AND (target_profession = 'Any' OR target_profession = ?)`);
            params.push(profession);
        }

        const trimmedKeyword = keyword?.trim();

        let schemes = [];
        if (trimmedKeyword) {
            const query = `
                SELECT *,
                    (MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)) + 
                    (CASE WHEN scheme_name LIKE ? THEN 5 ELSE 0 END) as relevance
                FROM schemes
                WHERE MATCH(scheme_name, summary, description) AGAINST(? IN NATURAL LANGUAGE MODE)
                ${filters.join('')}
                ORDER BY relevance DESC, scheme_name ASC
                LIMIT 20;
            `;
            const queryParams = [trimmedKeyword, `%${trimmedKeyword}%`, trimmedKeyword, ...params];
            schemes = await executeQuery(query, queryParams);
        } else {
            const baseQuery = `SELECT * FROM schemes WHERE 1=1 ${filters.join('')} ORDER BY scheme_name ASC`;
            schemes = await executeQuery(baseQuery, params);
        }

        // Final safety filter in application layer to drop obviously irrelevant schemes
        // based on inferred age and profession. This guards against any mistakes in
        // model output or SQL and applies to all NL-search queries.
        try {
            if (parsedFilters.age) {
                const userAge = parsedFilters.age;
                schemes = schemes.filter(s => {
                    const minAge = typeof s.min_age === 'number' ? s.min_age : parseInt(s.min_age, 10);
                    const maxAge = typeof s.max_age === 'number' ? s.max_age : parseInt(s.max_age, 10);

                    // If ages are missing or invalid, keep the scheme (we don't want to over-filter).
                    if (isNaN(minAge) && isNaN(maxAge)) return true;
                    if (!isNaN(minAge) && userAge < minAge) return false;
                    if (!isNaN(maxAge) && userAge > maxAge) return false;
                    return true;
                });
            }

            if (parsedFilters.profession) {
                const prof = parsedFilters.profession;
                schemes = schemes.filter(s => {
                    const targetProf = (s.target_profession || '').trim();
                    if (!targetProf || targetProf.toLowerCase() === 'any') return true;
                    return targetProf === prof;
                });
            }
        } catch (postFilterErr) {
            console.log('NL search post-filter warning:', postFilterErr.message);
        }

        return res.json({
            success: true,
            schemes,
            appliedFilters: parsedFilters,
            model: modelUsed,
            message: `Found ${schemes.length} schemes for your query`
        });

    } catch (error) {
        console.error('Natural language search error:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
});

// Get all schemes (for admin or general browsing)
router.get('/', verifyToken, async (req, res) => {
    try {
        const { limit = 20, offset = 0 } = req.query;
        
        const schemes = await executeQuery(`
            SELECT id, scheme_name, summary, min_age, max_age, 
                   target_gender, target_caste, max_income, target_profession
            FROM schemes 
            ORDER BY scheme_name ASC
            LIMIT ? OFFSET ?
        `, [parseInt(limit), parseInt(offset)]);
        
        const totalCount = await executeQuery('SELECT COUNT(*) as total FROM schemes');
        
        res.json({
            success: true,
            schemes: schemes,
            total: totalCount[0].total,
            limit: parseInt(limit),
            offset: parseInt(offset)
        });
        
    } catch (error) {
        console.error('Schemes fetch error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

module.exports = router;
