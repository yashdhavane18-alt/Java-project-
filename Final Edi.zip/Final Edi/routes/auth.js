const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { executeQuery } = require('../db');
const router = express.Router();

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
        return res.status(401).json({ success: false, message: 'Access token required' });
    }
    
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Invalid token' });
    }
};

// User Registration
router.post('/register', async (req, res) => {
    try {
        const { full_name, email, password, age, gender, caste, income, profession } = req.body;
        
        // Validation
        if (!full_name || !email || !password || !age || !gender || !caste || !income || !profession) {
            return res.status(400).json({ 
                success: false, 
                message: 'All fields are required' 
            });
        }
        
        // Check if user already exists
        const existingUser = await executeQuery(
            'SELECT id FROM users WHERE email = ?', 
            [email]
        );
        
        if (existingUser.length > 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'User already exists with this email' 
            });
        }
        
        // Hash password
        const saltRounds = 12;
        const password_hash = await bcrypt.hash(password, saltRounds);
        
        // Insert new user
        const result = await executeQuery(
            `INSERT INTO users (full_name, email, password_hash, age, gender, caste, income, profession) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [full_name, email, password_hash, age, gender, caste, income, profession]
        );
        const isAdmin = process.env.ADMIN_EMAIL && email === process.env.ADMIN_EMAIL;
        
        // Generate JWT token
        const token = jwt.sign(
            { 
                userId: result.insertId, 
                email: email,
                full_name: full_name,
                isAdmin: !!isAdmin
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            token: token,
            user: {
                id: result.insertId,
                full_name: full_name,
                email: email,
                isAdmin: !!isAdmin,
                age: age,
                gender: gender,
                caste: caste,
                income: income,
                profession: profession
            }
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// User Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Validation
        if (!email || !password) {
            return res.status(400).json({ 
                success: false, 
                message: 'Email and password are required' 
            });
        }
        
        // Find user
        const users = await executeQuery(
            'SELECT * FROM users WHERE email = ?', 
            [email]
        );
        
        if (users.length === 0) {
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password' 
            });
        }
        
        const user = users[0];
        const isAdmin = process.env.ADMIN_EMAIL && user.email === process.env.ADMIN_EMAIL;
        
        // Verify password
        const isPasswordValid = await bcrypt.compare(password, user.password_hash);
        
        if (!isPasswordValid) {
            return res.status(401).json({ 
                success: false, 
                message: 'Invalid email or password' 
            });
        }
        
        // Generate JWT token
        const token = jwt.sign(
            { 
                userId: user.id, 
                email: user.email,
                full_name: user.full_name,
                isAdmin: !!isAdmin
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );
        
        res.json({
            success: true,
            message: 'Login successful',
            token: token,
            user: {
                id: user.id,
                full_name: user.full_name,
                email: user.email,
                isAdmin: !!isAdmin,
                age: user.age,
                gender: user.gender,
                caste: user.caste,
                income: user.income,
                profession: user.profession
            }
        });
        
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Get current user profile
router.get('/profile', verifyToken, async (req, res) => {
    try {
        const users = await executeQuery(
            'SELECT id, full_name, email, age, gender, caste, income, profession, created_at FROM users WHERE id = ?',
            [req.user.userId]
        );
        
        if (users.length === 0) {
            return res.status(404).json({ 
                success: false, 
                message: 'User not found' 
            });
        }
        
        res.json({
            success: true,
            user: users[0]
        });
        
    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

// Update user profile
router.put('/profile', verifyToken, async (req, res) => {
    try {
        const { full_name, age, gender, caste, income, profession } = req.body;
        
        await executeQuery(
            `UPDATE users SET full_name = ?, age = ?, gender = ?, caste = ?, income = ?, profession = ? 
             WHERE id = ?`,
            [full_name, age, gender, caste, income, profession, req.user.userId]
        );
        
        res.json({
            success: true,
            message: 'Profile updated successfully'
        });
        
    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Internal server error' 
        });
    }
});

module.exports = { router, verifyToken };
