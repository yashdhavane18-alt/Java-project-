const express = require('express');
const { executeQuery } = require('../db');
const { verifyToken } = require('./auth');

const router = express.Router();

// Simple admin guard based on email from JWT and ADMIN_EMAIL env
function requireAdmin(req, res, next) {
    const adminEmail = process.env.ADMIN_EMAIL;
    if (!adminEmail) {
        return res.status(500).json({
            success: false,
            message: 'Admin access is not configured (missing ADMIN_EMAIL).'
        });
    }

    if (!req.user || req.user.email !== adminEmail) {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Admins only.'
        });
    }

    next();
}

// Analytics overview: top schemes and search stats
router.get('/analytics/overview', verifyToken, requireAdmin, async (req, res) => {
    try {
        const [topViewed, topBookmarked, topSearches, zeroResultSearches] = await Promise.all([
            executeQuery(`
                SELECT s.id, s.scheme_name, COUNT(v.view_id) AS views
                FROM schemes s
                JOIN scheme_views v ON s.id = v.scheme_id
                GROUP BY s.id
                ORDER BY views DESC
                LIMIT 10
            `),
            executeQuery(`
                SELECT s.id, s.scheme_name, COUNT(b.bookmark_id) AS bookmarks
                FROM schemes s
                JOIN bookmarks b ON s.id = b.scheme_id
                GROUP BY s.id
                ORDER BY bookmarks DESC
                LIMIT 10
            `),
            executeQuery(`
                SELECT keyword, COUNT(*) AS searches, SUM(results_count = 0) AS zero_results
                FROM search_logs
                WHERE keyword IS NOT NULL AND keyword <> ''
                GROUP BY keyword
                ORDER BY searches DESC
                LIMIT 10
            `),
            executeQuery(`
                SELECT keyword, COUNT(*) AS occurrences
                FROM search_logs
                WHERE results_count = 0 AND keyword IS NOT NULL AND keyword <> ''
                GROUP BY keyword
                ORDER BY occurrences DESC
                LIMIT 10
            `)
        ]);

        res.json({
            success: true,
            analytics: {
                topViewed,
                topBookmarked,
                topSearches,
                zeroResultSearches
            }
        });
    } catch (error) {
        console.error('Admin analytics overview error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to load analytics overview.'
        });
    }
});

// Create a new scheme
router.post('/schemes', verifyToken, requireAdmin, async (req, res) => {
    try {
        const {
            scheme_name,
            summary,
            description,
            benefits,
            eligibility,
            documents_required,
            application_process,
            official_link,
            min_age,
            max_age,
            target_gender,
            target_caste,
            max_income,
            target_profession
        } = req.body;

        if (!scheme_name || !summary || !description || !benefits || !eligibility || !documents_required || !application_process) {
            return res.status(400).json({
                success: false,
                message: 'scheme_name, summary, description, benefits, eligibility, documents_required and application_process are required.'
            });
        }

        const result = await executeQuery(`
            INSERT INTO schemes (
                scheme_name, summary, description, benefits,
                eligibility, documents_required, application_process,
                official_link, min_age, max_age,
                target_gender, target_caste, max_income, target_profession
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            scheme_name,
            summary,
            description,
            benefits,
            eligibility,
            documents_required,
            application_process,
            official_link || null,
            min_age ?? 0,
            max_age ?? 100,
            target_gender || 'Any',
            target_caste || 'Any',
            max_income || 'Any',
            target_profession || 'Any'
        ]);

        res.status(201).json({
            success: true,
            message: 'Scheme created successfully',
            schemeId: result.insertId
        });
    } catch (error) {
        console.error('Admin create scheme error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create scheme.'
        });
    }
});

// Update an existing scheme
router.put('/schemes/:id', verifyToken, requireAdmin, async (req, res) => {
    try {
        const schemeId = req.params.id;
        const {
            scheme_name,
            summary,
            description,
            benefits,
            eligibility,
            documents_required,
            application_process,
            official_link,
            min_age,
            max_age,
            target_gender,
            target_caste,
            max_income,
            target_profession
        } = req.body;

        const existing = await executeQuery('SELECT id FROM schemes WHERE id = ?', [schemeId]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Scheme not found.'
            });
        }

        await executeQuery(`
            UPDATE schemes SET
                scheme_name = ?,
                summary = ?,
                description = ?,
                benefits = ?,
                eligibility = ?,
                documents_required = ?,
                application_process = ?,
                official_link = ?,
                min_age = ?,
                max_age = ?,
                target_gender = ?,
                target_caste = ?,
                max_income = ?,
                target_profession = ?
            WHERE id = ?
        `, [
            scheme_name,
            summary,
            description,
            benefits,
            eligibility,
            documents_required,
            application_process,
            official_link || null,
            min_age ?? 0,
            max_age ?? 100,
            target_gender || 'Any',
            target_caste || 'Any',
            max_income || 'Any',
            target_profession || 'Any',
            schemeId
        ]);

        res.json({
            success: true,
            message: 'Scheme updated successfully'
        });
    } catch (error) {
        console.error('Admin update scheme error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update scheme.'
        });
    }
});

// Delete a scheme
router.delete('/schemes/:id', verifyToken, requireAdmin, async (req, res) => {
    try {
        const schemeId = req.params.id;

        const existing = await executeQuery('SELECT id FROM schemes WHERE id = ?', [schemeId]);
        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Scheme not found.'
            });
        }

        await executeQuery('DELETE FROM schemes WHERE id = ?', [schemeId]);

        res.json({
            success: true,
            message: 'Scheme deleted successfully'
        });
    } catch (error) {
        console.error('Admin delete scheme error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete scheme.'
        });
    }
});

// Get full scheme details for admin editing
router.get('/schemes/:id', verifyToken, requireAdmin, async (req, res) => {
    try {
        const schemeId = req.params.id;

        const schemes = await executeQuery(
            `SELECT * FROM schemes WHERE id = ?`,
            [schemeId]
        );

        if (schemes.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Scheme not found.'
            });
        }

        res.json({
            success: true,
            scheme: schemes[0]
        });
    } catch (error) {
        console.error('Admin get scheme error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to load scheme.'
        });
    }
});

// Simple schemes list for admin
router.get('/schemes', verifyToken, requireAdmin, async (req, res) => {
    try {
        const schemes = await executeQuery(`
            SELECT id, scheme_name, summary, min_age, max_age,
                   target_gender, target_caste, max_income, target_profession,
                   created_at
            FROM schemes
            ORDER BY created_at DESC
        `);

        res.json({
            success: true,
            schemes
        });
    } catch (error) {
        console.error('Admin schemes list error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to load schemes.'
        });
    }
});

module.exports = router;
